import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

const CRUDpage = () => {
  const [exercises, setExercises] = useState([]);
  const [exerciseName, setExerciseName] = useState('');
  const [selectedExercise, setSelectedExercise] = useState(null);

  const addExercise = () => {
    if (exerciseName) {
      setExercises([...exercises, { id: Date.now().toString(), name: exerciseName }]);
      setExerciseName('');
    }
  };

  const updateExercise = () => {
    if (selectedExercise) {
      setExercises(exercises.map(ex => (ex.id === selectedExercise.id ? { ...ex, name: exerciseName } : ex)));
      setSelectedExercise(null);
      setExerciseName('');
    }
  };

  const deleteExercise = (id) => {
    setExercises(exercises.filter(ex => ex.id !== id));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Types Exercise </Text>
      <TextInput
        style={styles.input}
        placeholder="Enter Exercise Name"
        value={exerciseName}
        onChangeText={setExerciseName}
      />
      <View style={styles.buttonContainer}>
        {selectedExercise ? (
          <Button title="Update Exercise" onPress={updateExercise} />
        ) : (
          <Button title="Add Exercise" onPress={addExercise} />
        )}
      </View>

      <FlatList
        data={exercises}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.exerciseItem}>
            <Text>{item.name}</Text>
            <TouchableOpacity onPress={() => {
              setSelectedExercise(item);
              setExerciseName(item.name);
            }}>
              <Text style={styles.editButton}>Edit</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => deleteExercise(item.id)}>
              <Text style={styles.deleteButton}>Delete</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 20,
    borderRadius: 5,
  },
  buttonContainer: {
    marginBottom: 20,
  },
  exerciseItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  editButton: {
    color: 'blue',
    marginRight: 10,
  },
  deleteButton: {
    color: 'red',
  },
});

export default CRUDpage;
